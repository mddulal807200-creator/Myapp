co<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Elite Business Portal</title>

<style>
:root{
 --primary:#0f6b50;
 --bg:#f4f6f9;
 --card:#ffffff;
 --text:#222;
}
body.dark{
 --bg:#121212;
 --card:#1e1e1e;
 --text:#f1f1f1;
}
body{
 margin:0;
 font-family:Arial;
 background:var(--bg);
 color:var(--text);
 display:flex;
}
.hidden{display:none;}
.sidebar{
 width:200px;
 background:var(--primary);
 color:white;
 height:100vh;
 padding:20px;
 position:fixed;
}
.sidebar button{
 width:100%;
 margin:8px 0;
 background:white;
 color:var(--primary);
 border:none;
 padding:8px;
 border-radius:6px;
}
.main{
 margin-left:200px;
 padding:20px;
 width:100%;
}
.card{
 background:var(--card);
 padding:15px;
 margin-top:15px;
 border-radius:12px;
 box-shadow:0 5px 15px rgba(0,0,0,0.1);
}
button{
 padding:8px 12px;
 margin-top:10px;
 border:none;
 background:var(--primary);
 color:white;
 border-radius:6px;
}
#login,#verify,#loading{
 position:fixed;
 width:100%;
 height:100%;
 background:#111;
 color:white;
 display:flex;
 flex-direction:column;
 justify-content:center;
 align-items:center;
}
input{
 padding:8px;
 width:200px;
}
.counter{font-weight:bold;font-size:18px;}
</style>
</head>
<body>

<div id="login">
<h2>🔐 Secure Login</h2>
<input type="password" id="pin" placeholder="Enter PIN">
<br><br>
<button onclick="login()">Login</button>
</div>

<div id="verify" class="hidden">
<h3>📱 Verification Code</h3>
<input type="text" id="code" placeholder="Enter Code">
<br><br>
<button onclick="verify()">Verify</button>
</div>

<div id="loading" class="hidden">
<h2>Loading Portal...</h2>
</div>

<div id="portal" class="hidden" style="width:100%;">

<div class="sidebar">
<h3>Business Portal</h3>
<button onclick="showPage('home')">Dashboard</button>
<button onclick="showPage('services')">Services</button>
<button onclick="showPage('profile')">Profile</button>
<button onclick="logout()">Logout</button>
</div>

<div class="main">

<h3>ROKIBUL HASSAN</h3>
<p>ID-2447788665</p>
<p id="clock"></p>

<div id="home" class="page">
<div class="card">
Active Files: <span class="counter" id="c1">0</span><br>
Pending: <span class="counter" id="c2">0</span>
</div>
</div>

<div id="services" class="page hidden">
<div class="card">Commercial Registration</div>
<div class="card">Tax Services</div>
<div class="card">Document Center</div>
<div class="card">License Renewal</div>
</div>

<div id="profile" class="page hidden">
<div class="card">
Name: ROKIBUL HASSAN<br>
ID: 2447788665<br>
Status: Active Business User
</div>
<button onclick="toggleMode()">Toggle Dark/Light</button>
</div>

</div>
</div>

<script>
const PIN="2447";
const CODE="1234";

function login(){
 if(pin.value===PIN){
  login.style.display="none";
  verify.style.display="flex";
 }else alert("Wrong PIN");
}

function verify(){
 if(code.value===CODE){
  verify.style.display="none";
  loading.style.display="flex";
  setTimeout(()=>{
   loading.style.display="none";
   portal.style.display="flex";
   startCounters();
  },1200);
 }else alert("Wrong Code");
}

function logout(){location.reload();}

function toggleMode(){document.body.classList.toggle("dark");}

function showPage(page){
 document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
 document.getElementById(page).classList.remove("hidden");
}

setInterval(()=>{
 document.getElementById("clock").innerHTML=new Date().toLocaleString();
},1000);

function startCounters(){
 let a=0,b=0;
 let i=setInterval(()=>{
  if(a<18)a++;
  if(b<6)b++;
  c1.innerHTML=a;
  c2.innerHTML=b;
  if(a>=18&&b>=6)clearInterval(i);
 },80);
}
</script>

</body>
</html>nsole.log('Hello World!');
